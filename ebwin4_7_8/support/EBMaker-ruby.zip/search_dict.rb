require "kconv"
load 'EBDict.rb'

dictname = nil
keyword = nil
searchMethod	=	EBDict::IndexType::FWD

while arg = ARGV.shift
	if /^-/ =~ arg
		case arg
		when '-m=e'
			searchMethod	=	EBDict::IndexType::EXACT
		when '-m=p','-m=f'
			searchMethod	=	EBDict::IndexType::FWD
		when '-m=s','-m=b'
			searchMethod	=	EBDict::IndexType::BWD
		when '-m=c'
			searchMethod	=	EBDict::IndexType::CROSS
		end
	elsif dictname.nil? 
		dictname = arg
	elsif keyword.nil?
		keyword = arg
	end
end

if keyword.nil?
	exit
end

dict = EBDict::Dictionary.new

dict.open(dictname)

dict.search(keyword,searchMethod).each{|id|
  row = dict.searchById( id )
  puts Kconv.tosjis( row.join("\t") )
#  puts row.join("\t") 
}

dict.close()


