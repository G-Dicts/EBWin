#------------------------------------------------------------
#	Name	:dict_load_pdic.rb
#	Date	:2008/09/01
#	Update	:2015/01/30	Ver2.0
#	Author	:hishida
#	purpose	:convert eijiro format to SQLite3
#	usage	:dict_load_pdic.rb <infile> <dbfile> <booktitle> <encode>
#------------------------------------------------------------

require "kconv"
load 'EBDict.rb'

limitCount = 0

in_filename = ARGV[0]
dbname = ARGV[1]
booktitle = ARGV[2]
encstr = ARGV[3]

#

if File::exist?( dbname )
	File::delete( dbname )
end

dict = EBDict::Dictionary.new
dict.create(dbname,
{'booktitle'=>booktitle,'indexmask'=>EBDict::IndexType::FWD|EBDict::IndexType::BWD|EBDict::IndexType::CROSS,'contenttype'=>EBDict::ContentType::HTML})
#

case encstr
when 'utf8','UTF8','utf-8','UTF-8'
	encode = Kconv::UTF8
	openmode='rb:UTF-8'
when 'utf16','UTF16','UTF-16','UTF-16'
	encode = Kconv::UTF8
	openmode='rb:UTF-16LE:UTF-8'
when 'euc','EUC'
	encode = Kconv::EUC
	openmode='r'
else
	encode = Kconv::SJIS
	openmode='r'
end



#dict = EBDict::Dictionary.new

dict.open(dbname)

dict.begin()

linecnt	= 0

File::open(in_filename, openmode) { |f|

	header	= ""
	f.each { |line|
		if encode != Kconv::UTF8
			line = line.kconv(Kconv::UTF8,encode)
		end
		line.chomp!
		rowid = 0
		seq = 0
		if linecnt % 2 == 1

			a = header.split(/\t/,2)	# 検索文字列\t表示文字列
			if a[1].nil? 
				a[1]	= a[0]
			end
			headword = a[1]
			keyword	= a[0]
			keyword.downcase!
			keyword.gsub!(/-/,'')

			meaning	= line
			meaning.gsub!(/'/,'&apos;')
			meaning.gsub!(/"/,'&quot;')

#			rowid = insert( idkey,headword,meaning,phonetic,keyword,kana,level=0 )
			rowid = dict.insert("",headword,meaning,"",keyword,"",0)

			header	= ""
		else
			header 	= line
		end
		linecnt = linecnt+1
		if linecnt%1000==0
			print linecnt.to_s+"\r"
		end
		break if limitCount>0 && linecnt>limitCount
	}
}
print linecnt.to_s+"\r"
print "\n"

dict.commit()

dict.close()


