#------------------------------------------------------------
#	Name	:dict_load_edict.rb
#	Update	:2015/05/11
#	Author	:hishida
#	purpose	:convert eijiro format to SQLite3
#	usage	:dict_load_pdic.rb <infile> <dbfile> <booktitle> <encode>
#------------------------------------------------------------

require "kconv"
load 'EBDict.rb'

limitCount = 0

in_filename = ARGV[0]
dbname = ARGV[1]
booktitle = ARGV[2]
encstr = ARGV[3]

#

if File::exist?( dbname )
	File::delete( dbname )
end

dict = EBDict::Dictionary.new
dict.create(dbname,
{'booktitle'=>booktitle,'indexmask'=>EBDict::IndexType::FWD|EBDict::IndexType::BWD|EBDict::IndexType::CROSS,'contenttype'=>EBDict::ContentType::HTML})
#

case encstr
when 'utf8','UTF8','utf-8','UTF-8'
	encode = Kconv::UTF8
	openmode='rb:UTF-8'
when 'utf16','UTF16','UTF-16','UTF-16'
	encode = Kconv::UTF8
	openmode='rb:UTF-16LE:UTF-8'
when 'euc','EUC'
	encode = Kconv::EUC
	openmode='r'
else
	encode = Kconv::SJIS
	openmode='r'
end



#dict = EBDict::Dictionary.new

dict.open(dbname)

dict.begin()

linecnt	= 0

File::open(in_filename, openmode) { |f|

	f.each { |line|
		if encode != Kconv::UTF8
			line = line.kconv(Kconv::UTF8,encode)
		end
		line.chomp!
		rowid = 0
		seq = 0

		a = line.split(/\//,2)

		if /(.+) \[(.+)\] / =~ a[0] then
			keyword	=$1
			kana	=$2
		else
			keyword	=a[0]
			kana		=''
		end
		keyword.downcase!
		keyword.gsub!(/-/,'')

		meaning		=a[1]
		meaning.gsub!(/\/$/,'')
		meaning.gsub!(/'/,'&apos;')
		meaning.gsub!(/"/,'&quot;')

#		rowid = insert( idkey,headword,meaning,phonetic,keyword,kana,level=0 )
		rowid = dict.insert("",a[0],meaning,"",keyword,kana,0)

		linecnt = linecnt+1
		if linecnt%1000==0
			print linecnt.to_s+"\r"
		end
		break if limitCount>0 && linecnt>limitCount
	}
}
print linecnt.to_s+"\r"
print "\n"

dict.commit()

dict.close()


