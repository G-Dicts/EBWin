#	Name:	EBDict.rb
#	Authoe:	hishida
#	Date:	2008/10/10
#	Update:	2015/01/30	Ver2.0
#	Purpose:access library for EBWin user dictionary
#
# Method:
#	new
#	create(dbname,options = {})	データベースの新規作成
#	open(dbname)			データベースのopen
#	close()				データベースのclose
#	begin()				トランザクション開始
#	commit()			トランザクション終了
#	rowid = insert( idkey,headword,meaning,phonetic,keyword,kana,level=0 )	項目の追加
#	delete( rowid )	項目の削除
#	update( rowid,idkey,headword,meaning,phonetic,keyword,kana,level=0 )	項目の修正
#	[] = searchById( rowid )	行idによる検索
#	[] = search( keyword,searchType=IndexType::FWD )	キーワードによる検索
#	InsertLink( rowid,attribute,relid,seq,comment )	リンクの追加
#	DeleteLink( rowid )	リンクの削除
#	InsertInfo(rowid,attribute,no,body)	付加情報の追加
#	DeleteInfo( rowid )	付加情報の削除
#	InsertIndex(rowid,attribute,tag,keyword)	インデックスの追加
#	DeleteIndex( rowid )	インデックスの削除
#
# Constant:
#	bookinfo.indexmask
#	link.attribute
#		IndexType::EXACT
#		IndexType::FWD
#		IndexType::BWD
#		IndexType::CROSS
#		IndexType::COND
#		IndexType::MULTI
#	bookinfo.contenttype
#		ContentType::PLAIN
#		ContentType::HTML
#		ContentType::XML
#	alt
#		LinkType::MENU
#		LinkType::REL
#		LinkType::SUPER
#		LinkType::SUB
#
#====================================

module EBDict

#  require 'jcode'
  require 'sqlite3'
  require 'digest/md5'

#  $KCODE="u"

#-------------------------------------
# Constant
#-------------------------------------
  # bookinfo.indexmask
  # altindex.attribute
  module IndexType
	EXACT	= 0x00
	FWD	= 0x01
	BWD	= 0x04
	CROSS	= 0x10
	COND	= 0x20
	MULTI	= 0x40
	MENU	= 0x80
  end

  # link.attribute
  module LinkType
	MENU	= 0x80
	REL	= 0x100
	SUPER	= 0x101
	SUB	= 0x102
  end

  # bookinfo.contenttype
  module ContentType
	PLAIN	= 0
	HTML	= 1
	XML	= 2
  end

#-------------------------------------
# Class definition
#-------------------------------------

class Dictionary

#-------------------------------------
# new
  def initialize
    @@db = nil
    @@OPT_TABLE = {}
  end

#-------------------------------------
# databaseの新規作成
  def create(dbname,options = {})

    @@OPT_TABLE = options

#<<SQL_DICT_VER==1
#    if @@OPT_TABLE['indexmask'].nil? || @@OPT_TABLE['indexmask']==0
#      @@OPT_TABLE['indexmask']	= IndexType::FWD
#    end
#>>

    @@OPT_TABLE['compression']	= (options['compression'].nil?)? 0 : options['compression']
    @@OPT_TABLE['crypt']	= (options['crypt'].nil?)? 0 : options['crypt']
    @@OPT_TABLE['contenttype']	= (options['contenttype'].nil?)? 0 : options['contenttype']

    md5 =  Digest::MD5.new.update(dbname)
    @@OPT_TABLE['bookno'] = md5.to_s[0,8].hex.to_i & 0x7FFFFFFF

#p @@OPT_TABLE

# データベースを作成する
    db = SQLite3::Database.new(dbname)

# テーブルを作成する
    sql = <<SQL
create table book
(
	id	INTEGER	primary key autoincrement,
	idkey	VARCHAR(32),
	no	VARCHAR(255),
	headword	VARCHAR(255),
	meaning	TEXT,
	phonetic	VARCHAR(255),
	keyword	 VARCHAR(255) COLLATE NOCASE ,
	kana	 VARCHAR(255) COLLATE NOCASE ,
	level	INTEGER
);
SQL
    db.execute( sql )

    sql = <<SQL
create index book_keyword_idkey on book(idkey);
SQL
    db.execute( sql )

#<< SQL_DICT_VER==2
    sql = <<SQL
create index book_keyword_idx on book(keyword COLLATE NOCASE);
SQL
    db.execute( sql )

    sql = <<SQL
create index book_kana_idx on book(kana COLLATE NOCASE);
SQL
    db.execute( sql )
#>>

  #----------------------------
    sql = <<SQL
create table altinfo
(
	id		INTEGER,
	attribute	INTEGER,
	no		VARCHAR(255),
	body		TEXT
);
SQL
    db.execute( sql )

  #----------------------------
    sql = <<SQL
create table altindex
(
	id		INTEGER,
	attribute	INTEGER,
	tag		VARCHAR(255) COLLATE NOCASE,
	keyword		VARCHAR(255) COLLATE NOCASE
);
SQL
    db.execute( sql )

    sql = <<SQL
create index altindex_keyword_idx on altindex(keyword COLLATE NOCASE,attribute);
SQL
    db.execute( sql )

  #----------------------------
    sql = <<SQL
create table link
(
	id		INTEGER,
	attribute	INTEGER,
	relid		INTEGER,
	seq		INTEGER,
	comment		VARCHAR(255)
);
SQL
    db.execute( sql )

  #----------------------------
    sql = <<SQL
create table bookinfo
(
	isbn		CHAR(13),
	ccode		CHAR(4),
	booktitle	VARCHAR(255),
	booksubtitle	VARCHAR(255),
	edition		VARCHAR(255),
	seriestitle	VARCHAR(255),
	bookauthor	VARCHAR(255),
	pubdate	CHAR(8),
	publisher	VARCHAR(255),

	bookcode	VARCHAR(255),
	filename	VARCHAR(255),
	compression	INTEGER,
	crypt		INTEGER,
	bookno		INTEGER,
	indexmask	INTEGER,
	contenttype	INTEGER
);
SQL
    db.execute( sql )

    sql = <<SQL
insert into bookinfo(isbn,ccode,booktitle,booksubtitle,edition,seriestitle,bookauthor,
  pubdate,publisher,bookcode,filename,compression,crypt,bookno,indexmask,contenttype) 
values (
  '#{@@OPT_TABLE['isbn']}',
  '#{@@OPT_TABLE['ccode']}',
  '#{@@OPT_TABLE['booktitle']}',
  '#{@@OPT_TABLE['booksubtitle']}',
  '#{@@OPT_TABLE['edition']}',
  '#{@@OPT_TABLE['seriestitle']}',
  '#{@@OPT_TABLE['bookauthor']}',
  '#{@@OPT_TABLE['pubdate']}',
  '#{@@OPT_TABLE['publisher']}',
  '#{@@OPT_TABLE['bookcode']}',
  '#{@@OPT_TABLE['filename']}',
  #{@@OPT_TABLE['compression']},
  #{@@OPT_TABLE['crypt']},
  #{@@OPT_TABLE['bookno']},
  #{@@OPT_TABLE['indexmask']},
  #{@@OPT_TABLE['contenttype']}
);
SQL
    db.execute( sql )

#----------------------------
#sql = <<SQL
#create table multimedia
#(
#	id		INTEGER,
#	MIME		INTEGER,
#	DATA		BLOB,
#	path		VARCHAR(255)
#);
#SQL
#db.execute( sql )

    db.close

  end

#-------------------------------------
# 書誌情報の読込
  def readHeader

    begin
      result = @@db.get_first_row('select isbn,ccode,booktitle,booksubtitle,edition,seriestitle,bookauthor,pubdate,publisher,bookcode,filename,compression,crypt,bookno,indexmask,contenttype from bookinfo')

      @@OPT_TABLE.clear

      @@OPT_TABLE['isbn']		= result[0]
      @@OPT_TABLE['ccode']	= result[1]
      @@OPT_TABLE['booktitle']	= result[2]
      @@OPT_TABLE['booksubtitle']	= result[3]
      @@OPT_TABLE['edition']	= result[4]
      @@OPT_TABLE['seriestitle']	= result[5]
      @@OPT_TABLE['bookauthor']	= result[6]
      @@OPT_TABLE['pubdate']	= result[7]
      @@OPT_TABLE['publisher']	= result[8]
      @@OPT_TABLE['bookcode']	= result[9]
      @@OPT_TABLE['filename']	= result[10]
      @@OPT_TABLE['compression']	= result[11].to_i
      @@OPT_TABLE['crypt']	= result[12].to_i
      @@OPT_TABLE['bookno']	= result[13].to_i
      @@OPT_TABLE['indexmask']	= result[14].to_i
      @@OPT_TABLE['contenttype']	= result[15].to_i
    end

#p @@OPT_TABLE

  end

#-------------------------------------
# databeseを開く
  def open(dbname)
    begin
      @@db = SQLite3::Database.open(dbname)
      readHeader()
    end
  end

#-------------------------------------
# databeseを閉じる
  def close()
    @@db.close
    @@db = nil
  end

#-------------------------------------
# 項目の追加
  def insert(idkey,headword,meaning,phonetic,keyword,kana,level=0)

    indexmask=@@OPT_TABLE['indexmask']

    sql = "insert into book(idkey,no,headword,meaning,phonetic,keyword,kana,level) values (?,?,?,?,?,?,?,?)"

    if ( keyword.nil? || keyword=="" ) 
      keyword	= headword
    end
    @@db.execute(sql,idkey,"",headword,meaning,phonetic,keyword,kana,level)

    rowid = @@db.last_insert_row_id()
    sql = "insert into altindex(id,attribute,tag,keyword) values (?,?,?,?)"

    # 前方一致
    if indexmask & IndexType::FWD == IndexType::FWD
      @@db.execute(sql,rowid,IndexType::FWD,"",keyword)
      if kana!=""
        @@db.execute(sql,rowid,IndexType::FWD,"",kana)
      end
    end
    # 後方一致
    if indexmask & IndexType::BWD == IndexType::BWD
      @@db.execute(sql,rowid,IndexType::BWD,"",keyword.split(//).reverse.join)
      if kana!=""
        @@db.execute(sql,rowid,IndexType::BWD,"",kana.split(//).reverse.join)
      end
    end
    # クロス検索
    if indexmask & IndexType::CROSS == IndexType::CROSS
      keyword.split(" ").each {|w|
        w.gsub!(/[^0-9_a-zA-Z\.]/,'')
        next if w.length<2
        @@db.execute(sql,rowid,IndexType::CROSS,"",w)
      }
      if kana!=""
        kana.split(" ").each {|w|
          w.gsub!(/[^0-9_a-zA-Z\.]/,'')
          next if w.length<2
          @@db.execute(sql,rowid,IndexType::CROSS,"",w)
        }
      end
    end

    return rowid
  end

#-------------------------------------
# 項目の削除
  def delete(rowid)
    sql = "delete from book where id=?"
    @@db.execute( sql, rowid )
  end

#-------------------------------------
# 項目の修正
  def update(rowid,idkey,headword,meaning,phonetic,keyword,kana,level=0)

    indexmask=@@OPT_TABLE['indexmask']

    sql = "update book set idkey='?',no='?',headword='?',meaning='?',phonetic='?',keyword='?',kana='?',level=? where id = ?"

    if ( keyword.nil? || keyword=="" ) 
      keyword	= headword
    end
    @@db.execute(sql,idkey,"",headword,meaning,phonetic,keyword,kana,level,rowid)

    sql = "delete from altindex where id=?"
    @@db.execute( sql, rowid )

    sql = "insert into altindex(id,attribute,tag,keyword) values (?,?,?,?)"

    # 前方一致
    if indexmask & IndexType::FWD == IndexType::FWD
      @@db.execute(sql,rowid,IndexType::FWD,"",keyword)
      if kana!=""
        @@db.execute(sql,rowid,IndexType::FWD,"",kana)
      end
    end
    # 後方一致
    if indexmask & IndexType::BWD == IndexType::BWD
      @@db.execute(sql,rowid,IndexType::BWD,"",keyword.split(//).reverse.join)
      if kana!=""
        @@db.execute(sql,rowid,IndexType::BWD,"",kana.split(//).reverse.join)
      end
    end
    # クロス検索
    if indexmask & IndexType::CROSS == IndexType::CROSS
      keyword.split(" ").each {|w|
        w.gsub!(/[^0-9_a-zA-Z\.]/,'')
        next if w.length<2
        @@db.execute(sql,rowid,IndexType::CROSS,"",w)
      }
      if kana!=""
        kana.split(" ").each {|w|
          w.gsub!(/[^0-9_a-zA-Z\.]/,'')
          next if w.length<2
          @@db.execute(sql,rowid,IndexType::CROSS,"",w)
        }
      end
    end

  end

#-------------------------------------
# リンクの追加・削除
  def InsertLink(rowid,attribute, relid, seq,comment)
    sql = "insert into link(id,attribute,relid,seq,comment) values (?,?,?,?,?)"
    @@db.execute( sql, rowid, attribute, relid, seq,comment )
  end

  def DeleteLink( rowid )
    sql = "delete from link where id=?"
    @@db.execute( sql, rowid )
  end

  def DeleteRelLink( rowid )
    sql = "delete from link where relid=?"
    @@db.execute( sql, rowid )
  end

#-------------------------------------
# 付加情報の追加・削除
  def InsertInfo(rowid,attribute, no, body)
    sql = "insert into altinfo(id,attribute,no,body) values (?,?,?,?)"
    @@db.execute( sql, rowid, attribute, no,body )
  end

  def DeleteInfo( rowid )
    sql = "delete from altinfo where id=?"
    @@db.execute( sql, rowid )
  end

#-------------------------------------
# インデックスの追加・削除
  def InsertIndex(rowid,attribute, tag, keyword)
    sql = "insert into altindex(id,attribute,tag,keyword) values (?,?,?,?)"
    @@db.execute( sql, rowid, attribute, tag, keyword )
  end

  def DeleteIndex( rowid )
    sql = "delete from altindex where id=?"
    @@db.execute( sql, rowid )
  end

#-------------------------------------
# トランザクションの開始
  def begin()

    @@db.execute("BEGIN")
  end

#-------------------------------------
# トランザクションの終了
  def commit()
    @@db.execute("COMMIT")
  end


#-------------------------------------
# 行idによる検索
  def searchById(rowid)
    sql = "SELECT id,idkey,headword,meaning,phonetic,keyword,kana,level FROM book WHERE id=?"
    return @@db.execute( sql, rowid )
    # 戻り値は列の配列
  end

#-------------------------------------
# キーワードによる検索
  def search(keyword,searchType=IndexType::FWD)

    indexmask=@@OPT_TABLE['indexmask']

    case searchType
    when IndexType::FWD	# 前方一致
	if indexmask & IndexType::FWD == IndexType::FWD
	    where_part = "id in (select id from altindex where (keyword like '#{keyword}%' and attribute=#{searchType}) )"
	else
	    where_part = "keyword like '#{keyword}%' or kana like '#{keyword}%' "
	end
    when IndexType::BWD	# 後方一致
        r_keyword = keyword.reverse
        where_part = "id in (select id from altindex where (keyword like '#{r_keyword}%' and attribute=#{searchType}) )"
    when IndexType::CROSS	# クロス条件検索
        where_part = "id in (select id from altindex where (keyword like '#{keyword}%' and attribute=#{searchType}) )"
    when IndexType::EXACT	# 完全一致
	if indexmask & IndexType::FWD == IndexType::FWD
		fwdType =IndexType::FWD
	    where_part = "id in (select id from altindex where (keyword = '#{keyword}' and attribute=#{fwdType}) )"
	else
	    where_part = "keyword like '#{keyword}' or kana like '#{keyword}' "
	end
    else
	where_part = "keyword like '#{keyword}%' or kana like '#{keyword}%' "
    end

#    sql = "SELECT id FROM book WHERE id in (select id from altindex where "+where_part+")"
    sql = "SELECT id FROM book WHERE "+where_part

# 戻り値はidの配列
    iDs=[]
    @@db.execute( sql ) { |a|
      iDs<<a[0].to_i
    }
    return iDs
  end

end	# class 

end	# module

