#!/bin/sh
TEXTFILE=edict2.txt
EBDFILE=edict2.ebd
TITLE=EDICT2
ENCODE=EUC

echo ruby dict_load_edict.rb $TEXTFILE $EBDFILE $TITLE $ENCODE
ruby ./dict_load_edict.rb $TEXTFILE $EBDFILE $TITLE $ENCODE
