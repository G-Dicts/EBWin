// FontDump.cpp : �R���\�[�� �A�v���P�[�V�����p�̃G���g�� �|�C���g�̒�`
//

#include "stdafx.h"
#include "FontDump.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// �B��̃A�v���P�[�V���� �I�u�W�F�N�g

CWinApp theApp;

using namespace std;

char blankDot	= ' ';

/////////////////////////////////////////////////////////////////////////////
// HEX�t�@�C������EBStudio�O���t�@�C�����쐬
/////////////////////////////////////////////////////////////////////////////
int ConvHEX2Txt( TCHAR* pszFileName, 
				int ebCode,		
				int	xsize,			// 0�ȊO�̎��Awidth�������I�ɐݒ�
				int	ysize,			// 0�ȊO�̎��Aheight�������I�ɐݒ�
				FILE*mapFp,
				int header )
{
	char buf[1024];	// 48*48�̏ꍇ�A576����
	FILE* fp = _tfopen( pszFileName, _T("r") );
	if ( fp == NULL )
		return 0;

	unsigned char *lpBits = NULL;
	DWORD dwWidth	= 16;	// ���h�b�g�\��
	DWORD dwHeight	= 16;	// �c�h�b�g�\��
	DWORD unicode;

	int lines = 0;
	while( fgets( buf,1024, fp ) != NULL ) {
		if ( lines == 0 ) {
			char *s1	= strtok( buf, " \r\n" );
			if ( s1 == NULL )	return 0;
			char *s2	= strtok( NULL, " \r\n" );
			if ( s2 == NULL )	return 0;
			dwWidth		= atoi( s1 );
			dwHeight	= atoi( s1 );

			// ���h�b�g�\��(8,12,16,24,32,48)
			if		( dwWidth<= 8 )	dwWidth	= 8;
			else if ( dwWidth<=12 )	dwWidth	= 12;
			else if ( dwWidth<=16 )	dwWidth	= 16;
			else if ( dwWidth<=24 )	dwWidth	= 24;
			else if ( dwWidth<=32 )	dwWidth	= 32;
			else					dwWidth	= 48;
			// �c�h�b�g�\��(16,24,32,48)
			if		( dwHeight<=16 )	dwHeight	= 16;
			else if ( dwHeight<=24 )	dwHeight	= 24;
			else if ( dwHeight<=32 )	dwHeight	= 32;
			else						dwHeight	= 48;
			if ( dwWidth < dwHeight )
				dwWidth = dwHeight / 2;
			if ( dwHeight == 32 )
				dwHeight	= 30;

			// �w�肪����Ƃ��͋�������
			if ( xsize>0 )
				dwWidth	= xsize;
			if ( ysize>0 )
				dwHeight	= ysize;

			lpBits = (unsigned char*)malloc( dwWidth * (dwHeight+1) );
			if ( lpBits==NULL )
				break;

			if ( header ) {
				printf( "<?xml version=\"1.0\" encoding=\"Shift_JIS\"?>\n");
				printf( "<gaijiData xml:space=\"preserve\">\n");
				printf( "<fontSet size=\"%dX%d\" start=\"%X\">\n",dwWidth,dwHeight,ebCode);
				if ( mapFp ) {
					fprintf( mapFp, "<?xml version=\"1.0\" encoding=\"Shift_JIS\"?>\n");
					fprintf( mapFp, "<gaijiSet>\n");
				}
			}

		}
		else {
			char *s_unicode	= strtok( buf, ":" );
			if ( s_unicode == NULL )
				return lines-1;
			sscanf( s_unicode,"%X", &unicode );

			char *bindata	= strtok( NULL, "\r\n" );
			
		// bitmap�f�[�^������
			if ( lpBits == NULL ) {
				return 0;
			}
			memset( lpBits, 0, dwWidth * dwHeight );
			// 1byte��
			for ( int nbyte =0; nbyte<strlen(bindata)/2 ; ++nbyte ) {
				int bdata;
				sscanf( bindata+nbyte*2,"%02X",&bdata );
				int k = nbyte*8;
				int b = 0x80;
				for ( int ix=0;ix<8;++ix ) {
					if ( k<0 || k>=dwWidth*dwHeight )
						break;
					lpBits[k++] = (bdata & b)>0?1:0;
					b=b>>1;
				}
			}

			// �t�H���g�o��
			printf( "<fontData ebcode=\"%X\" unicode=\"%X\">\n",
					ebCode,	unicode);
			for ( int hx=0;hx<dwHeight; ++hx ) {
				for ( int wx=0;wx<dwWidth; ++wx ) {
					int dot = lpBits[hx*dwWidth+wx];
					if ( dot ) 
						putchar( '#' );
					else
						putchar( blankDot );
				}
				printf("\n");
			}
			printf( "</fontData>\n");

			if ( mapFp ) {
				fprintf( mapFp, "<gaijiMap unicode=\"#x%04X\" ebcode=\"%04X\"/>\n", 
					unicode, ebCode );
			}
			++ebCode;
			if ( ( ebCode & 0xff ) > 0x7E ) {
				ebCode = ((( ebCode >> 8)+1)<<8) + 0x21;
			}
		}
		++lines;
	}

	fclose( fp );

	if ( lpBits ) 
		free( lpBits );

	if ( header ) {
		printf( "</fontSet>\n" );
		printf( "</gaijiData>\n" );
		if ( mapFp ) {
			fprintf( mapFp, "</gaijiSet>\n" );
		}
	}

	return lines-1;
}


/////////////////////////////////////////////////////////////////////////////
// BDF�t�@�C������EBStudio�O���t�@�C�����쐬
/////////////////////////////////////////////////////////////////////////////

typedef struct {
	int encoding;			// ENCODING	(�O���t�C���f�b�N�X)
	int FBw,FBh,FBox,FBoy;	// FONTBOUNDINGBOX 
	int BBw,BBh,BBox,BBoy;	// BBX
	int SWx,SWy;			// SWIDTH(�g��Ȃ�)
	int DWx,DWy;			// DWIDTH(�g��Ȃ�)
	int xoffs,yoffs;
} BDFChar;

int ConvBDF2Txt( TCHAR* pszFileName, 
				int fromCode,	// �J�n�R�[�h
				int toCode,		// �I���R�[�h
				int ebCode,		
				int unicode,
				int	xsize,			// 0�ȊO�̎��Awidth�������I�ɐݒ�
				int	ysize,			// 0�ȊO�̎��Aheight�������I�ɐݒ�
				FILE*mapFp,
				int header	)
{
	char buf[256];

	FILE* fp = _tfopen( pszFileName, _T("r") );
	if ( fp == NULL )
		return 0;

	unsigned char *lpBits = NULL;
	DWORD dwWidth	= 16;	// ���h�b�g�\��
	DWORD dwHeight	= 16;	// �c�h�b�g�\��

	BDFChar c;
	int _chars	= 0;	// CHARS	�����f�Ђ̌�
	while( fgets( buf,256, fp ) != NULL ) {
		char *word	= strtok( buf, " \r\n" );
		char *val1,*val2,*val3,*val4;
		if ( word == NULL )	continue;
		if ( strcmp( word, "CHARS" ) == 0 ) {
			if ( ( val1 = strtok( NULL, " \r\n" ) ) == NULL ) break;
			_chars	= atoi( val1 );
		}
		else if ( strcmp( word, "SIZE" ) == 0 ) {
		}
		else if ( strcmp( word, "FONTBOUNDINGBOX" ) == 0 ) {
			if ( ( val1 = strtok( NULL, " \r\n" ) ) == NULL ) break;
			if ( ( val2 = strtok( NULL, " \r\n" ) ) == NULL ) break;
			if ( ( val3 = strtok( NULL, " \r\n" ) ) == NULL ) break;
			if ( ( val4 = strtok( NULL, " \r\n" ) ) == NULL ) break;
			dwWidth	= c.FBw	= atoi( val1 );
			dwHeight= c.FBh	= atoi( val2 );
			if ( *val3 == '-' )
				c.FBox	= atoi( val3+1 ) * -1;
			else 
				c.FBox	= atoi( val3 );
			if ( *val4 == '-' )
				c.FBoy	= atoi( val4+1 ) * -1;
			else 
				c.FBoy	= atoi( val4 );
			if ( c.FBoy > 0 )	// ���_��BOUNDINGBOX�̊O���ɂ���ꍇ(jiskan16-2000-[12].bdf�p�␳)
				c.FBoy	*= -1;
			// ���h�b�g�\��(8,12,16,24,32,48)
			if		( dwWidth<= 8 )	dwWidth	= 8;
			else if ( dwWidth<=12 )	dwWidth	= 12;
			else if ( dwWidth<=16 )	dwWidth	= 16;
			else if ( dwWidth<=24 )	dwWidth	= 24;
			else if ( dwWidth<=32 )	dwWidth	= 32;
			else					dwWidth	= 48;
			// �c�h�b�g�\��(16,24,32,48)
			if		( dwHeight<=16 )	dwHeight	= 16;
			else if ( dwHeight<=24 )	dwHeight	= 24;
			else if ( dwHeight<=32 )	dwHeight	= 32;
			else						dwHeight	= 48;
			if ( dwWidth < dwHeight )
				dwWidth = dwHeight / 2;
			if ( dwHeight == 32 )
				dwHeight	= 30;

			// �w�肪����Ƃ��͋�������
			if ( xsize>0 )
				dwWidth	= xsize;
			if ( ysize>0 )
				dwHeight	= ysize;

			if ( lpBits != NULL ) {
				return 0;
			}
			lpBits = (unsigned char*)malloc( dwWidth * (dwHeight+1) );
			if ( lpBits==NULL )
				break;

			if ( header ) {
				printf( "<?xml version=\"1.0\" encoding=\"Shift_JIS\"?>\n");
				printf( "<gaijiData xml:space=\"preserve\">\n");
				printf( "<fontSet size=\"%dX%d\" start=\"%X\">\n",dwWidth,dwHeight,ebCode);
				if ( mapFp ) {
					fprintf( mapFp, "<?xml version=\"1.0\" encoding=\"Shift_JIS\"?>\n");
					fprintf( mapFp, "<gaijiSet>\n");
				}
			}

		}
		else if ( strcmp( word, "STARTCHAR" ) == 0 ) {
			c.BBw = c.BBh = c.BBox = c.BBoy	= 0;
			c.SWx = c.SWy = c.DWx = c.DWy	= 0;
			if ( lpBits == NULL ) {
				return 0;
			}
			memset( lpBits,0,dwWidth * dwHeight );
		}
		else if ( strcmp( word, "ENCODING" ) == 0 ) {
			if ( ( val1 = strtok( NULL, " \r\n" ) ) == NULL ) break;
			c.encoding	= atoi( val1 );
		}
		else if ( strcmp( word, "BBX" ) == 0 ) {
			if ( ( val1 = strtok( NULL, " \r\n" ) ) == NULL ) break;
			if ( ( val2 = strtok( NULL, " \r\n" ) ) == NULL ) break;
			if ( ( val3 = strtok( NULL, " \r\n" ) ) == NULL ) break;
			if ( ( val4 = strtok( NULL, " \r\n" ) ) == NULL ) break;
			c.BBw	= atoi( val1 );
			c.BBh	= atoi( val2 );
			if ( *val3 == '-' )
				c.BBox	= atoi( val3+1 ) * -1;
			else 
				c.BBox	= atoi( val3 );
			if ( *val4 == '-' )
				c.BBoy	= atoi( val4+1 ) * -1;
			else 
				c.BBoy	= atoi( val4 );
			c.xoffs	= -c.FBox+c.BBox;
			c.yoffs	= (c.FBh + c.FBoy - c.BBoy) - c.BBh;
		}
		else if ( strcmp( word, "BITMAP" ) == 0 ) {
			int _line = 0;
			while( fgets( buf,256, fp ) != NULL ) {
				if ( strncmp( buf, "ENDCHAR",7 ) == 0 ) {
					if ( fromCode<=c.encoding && c.encoding<=toCode ) {
					/////////////////////////////////////////////////////////////////////////////////////////////
					//	printf("FBw=%d,FBh=%d,FBox=%d,FBoy=%d BBw=%d,BBh=%d,BBox=%d,BBoy=%d xoffs=%d yoffs=%d\n",
					//				c.FBw,c.FBh,c.FBox,c.FBoy,c.BBw,c.BBh,c.BBox,c.BBoy,c.xoffs,c.yoffs);
					/////////////////////////////////////////////////////////////////////////////////////////////
						// �t�H���g�o��
						printf( "<fontData code=\"%X\"  ebcode=\"%X\" unicode=\"%X\">\n",
								c.encoding, ebCode,	unicode);
						for ( int hx=0;hx<dwHeight; ++hx ) {
							for ( int wx=0;wx<dwWidth; ++wx ) {
								int dot = lpBits[hx*dwWidth+wx];
								if ( dot ) 
									putchar( '#'  );
								else
									putchar( blankDot );
							}
							printf("\n");
						}
						printf( "</fontData>\n");

						if ( mapFp ) {
							fprintf( mapFp, "<gaijiMap unicode=\"#x%04X\" ebcode=\"%04X\"/>\n", 
								unicode, ebCode );
						}

						++unicode;
						++ebCode;
						if ( ( ebCode & 0xff ) > 0x7E ) {
							ebCode = ((( ebCode >> 8)+1)<<8) + 0x21;
						}
					}
					break;
				}
				else {
					// bitmap�f�[�^������
					if ( _line < dwHeight ) {
						if ( lpBits == NULL ) {
							return 0;
						}
						// 1byte��
						int bmlen = min(c.BBw, dwWidth);
						if ( bmlen%8 != 0 ) 
							bmlen = (bmlen/8)*8 +8;		// 8�̔{���ɋ�������
						memset( lpBits+( _line+c.yoffs)*dwWidth,0,dwWidth);
						for ( int nbyte =0; nbyte<bmlen/8 ; ++nbyte ) {
							int bdata;
							sscanf( buf+nbyte*2,"%02X",&bdata );
							int k = ( _line+c.yoffs)*dwWidth+nbyte*8;
							if ( c.xoffs>0 )		k+= c.xoffs;
							else if ( c.xoffs<0 )	k-= c.xoffs;
							int b = 0x80;
							for ( int ix=0;ix<8;++ix ) {
								if ( k<0 || k>=dwWidth*dwHeight )
									break;
								lpBits[k++] = (bdata & b)>0?1:0;
								b=b>>1;
							}
						}
						++_line;
					}
				}
			}
		}
		else if ( strcmp( word, "ENDFONT" ) == 0 ) {
			// �t�@�C���̏I��
			break;
		}

	}

	fclose( fp );

	if ( lpBits ) 
		free( lpBits );

	if ( header ) {
		printf( "</fontSet>\n" );
		printf( "</gaijiData>\n" );
		if ( mapFp ) {
			fprintf( mapFp, "</gaijiSet>\n" );
		}
	}

	return _chars;
}


/////////////////////////////////////////////////////////////////////////////
// �w�肵���R�[�h���AEBStudio�O���e�L�X�g�`���ŏo��
/////////////////////////////////////////////////////////////////////////////
int ConvTTF2Txt(	int code,
				DWORD dwWidth, // ���h�b�g�\��(8,12,16,24,32,48)
				DWORD dwHeight, // �c�h�b�g�\��(16,24,30,48)
				int ebCode,
				LPCTSTR fontface,
				int unicode,
				int base)
{

	CDC memDC;
	CBitmap bitmap; 
	CFont font;
	// �������f�o�C�X�R���e�L�X�g�̍쐬
	memDC.CreateCompatibleDC( NULL ); 

	TCHAR ch[4];
	ch[0] = ch[1] = ch[2] = ch[3] = 0;
#ifdef _UNICODE

	if ( code>0xFFFF ) {
		// �T���Q�[�g�y�A
		int _code = code;
		_code	-=	0x10000;
		ch[0]	= 0xD800 | ((_code >> 10) & 0x3FF);
		ch[1]	= 0xDC00 | (_code & 0x3FF);
		ch[2] = ' ';
	}
	else {
		ch[0] = code;
		ch[1] = ' ';
	}
	unicode	= code;
#else
	if ( code <= 255 ) {
		ch[0] = code;
		ch[1] = ' ';
	}
	else {
		ch[0] = code>>8;
		ch[1] = code & 255;
		ch[2] = ' ';
	}
#endif
	CString sch = CString(ch);

	if ( dwWidth>48 )	dwWidth	= 48;
	if ( dwHeight>48 )	dwHeight= 48;
	int size = max(dwWidth,dwHeight);

	// �r�b�g�}�b�v�̍쐬
	bitmap.CreateCompatibleBitmap( &memDC, 48, 48 );	// �ō�48x48
	CBitmap* pOldBitmap = memDC.SelectObject( &bitmap );

	memDC.BitBlt( 0, 0, 48, 48, &memDC, 0, 0, WHITENESS ); // clear

	font.CreatePointFont((int)(size*7.5),fontface);	// �|�C���g��*10

//	double scale = pointSize*10.0/((y==30)?32:y);
//	font.CreatePointFont((int)(((y==30)?32:y)*scale),fontface);	

	CFont* pOldFont = memDC.SelectObject( &font );

	// �e�L�X�g�̏�������
	memDC.TextOut( 0, 0, sch ); 


	BYTE lpBits[288];
	bitmap.GetBitmapBits( 288, lpBits );

	WORD	w,b;

	printf( "<fontData ebcode=\"%X\" unicode=\"%X\">\n",ebCode,unicode);

	for ( int j=0+base;j<dwHeight+base; ++j ) {
		int nx = 0;
		for ( int i=0;i<6; ++i ) {
			w = lpBits[j*6+i];
			b = 0x80;
			while ( b>0 ) {
				if ( w & b ) 
					putchar( blankDot );
				else
					putchar( '#'  );
				b = b >> 1;
				++nx;
				if ( nx == dwWidth )
					goto exitloop;
			}
		}
exitloop:
		printf("\n");
	}

	printf( "</fontData>\n");

	memDC.SelectObject( pOldBitmap );
	DeleteObject( bitmap );
	memDC.SelectObject( pOldFont );
	DeleteObject( font );


	return TRUE;

} 


/////////////////////////////////////////////////////////////////////////////
// �w�肵���R�[�h���A�w�肵���T�C�Y��2�lBMP�t�@�C���ɏo��
/////////////////////////////////////////////////////////////////////////////
int ConvTTF2BMP(	int code,		// �\�����镶���R�[�h
				DWORD dwWidth,
				DWORD dwHeight,
				LPCTSTR fontface,	// �t�H���g�t�F�[�X��
				LPCTSTR lpszFileName 
				)
{
	CDC memDC;
	CBitmap bitmap; 
	CFont font;

	if ( dwWidth == 0 || dwHeight==0 )
		return -1;

	TCHAR ch[4];
	ch[0] = ch[1] = ch[2] = ch[3] = 0;
#ifdef _UNICODE
	if ( code>0xFFFF ) {
		// �T���Q�[�g�y�A
		int _code = code;
		_code	-=	0x10000;
		ch[0]	= 0xD800 | ((_code >> 10) & 0x3FF);
		ch[1]	= 0xDC00 | (_code & 0x3FF);
		ch[2] = ' ';
	}
	else {
		ch[0] = code;
		ch[1] = ' ';
	}
#else
	if ( code <= 255 ) {
		ch[0] = code;
		ch[1] = ' ';
	}
	else {
		ch[0] = code>>8;
		ch[1] = code & 255;
		ch[2] = ' ';
	}
#endif
	CString sch = CString(ch);

	if ( dwWidth%8 != 0 ) 
		dwWidth = (dwWidth/8)*8 +8;		// 8�̔{���ɋ�������
	if ( dwHeight%8 != 0 ) 
		dwHeight = (dwHeight/8)*8 +8;	// 8�̔{���ɋ�������
	int size = max(dwWidth,dwHeight);

	// �������f�o�C�X�R���e�L�X�g�̍쐬
	memDC.CreateCompatibleDC( NULL ); 

	// �r�b�g�}�b�v�̍쐬
	bitmap.CreateCompatibleBitmap( &memDC, dwWidth, dwHeight );
	CBitmap* pOldBitmap = memDC.SelectObject( &bitmap );

	memDC.BitBlt( 0, 0, dwWidth, dwHeight, &memDC, 0, 0, WHITENESS ); // clear

	font.CreatePointFont((int)(size*7.5),fontface);	// �|�C���g��*10

	CFont* pOldFont = memDC.SelectObject( &font );

	// �e�L�X�g�̏�������
	memDC.TextOut( 0, 0, sch ); 
	memDC.SelectObject( pOldFont );

	///////////////////////////////////////////////////////////////////////////
	// CBitmap�̃t�@�C����������
	///////////////////////////////////////////////////////////////////////////
	DWORD dwSize,dwFSize,dwLength;
	HANDLE fh;
	LPBITMAPFILEHEADER lpHead;
	LPBITMAPINFOHEADER lpInfo;
	LPBYTE lpBuf,lpPixel;
	RGBQUAD *lpRGB;

	// �������ݗp�o�b�t�@�̃T�C�Y�v�Z
	int rgb_count;
	int _biBitCount = 1;	// 2�l�̏ꍇ1

	switch ( _biBitCount ) {
	case 1:
		rgb_count = 2;
		dwLength=(((dwWidth / 4) + 3) & 0xfffffffc);
		break;
	case 4:
		rgb_count = 16;
		dwLength=(((dwWidth / 2) + 3) & 0xfffffffc);
		break;
	case 8:
		rgb_count = 256;
		dwLength=((dwWidth + 3) & 0xfffffffc);
		break;
	case 24:
		rgb_count = 0;
		dwLength=((dwWidth * 3 + 3) & 0xfffffffc);
		break;
	}

	dwFSize=  sizeof(BITMAPFILEHEADER)
			+ sizeof(BITMAPINFOHEADER)
			+ sizeof(RGBQUAD)*rgb_count	// �J���[�p���b�g(2�l�p)
			+ dwLength*dwHeight;	// �r�b�g�}�b�v�C���[�W

	// �o�b�t�@�m�ۂƃ|�C���^�ݒ�
	lpBuf=(LPBYTE)GlobalAlloc(GPTR,dwFSize);
	lpHead=(LPBITMAPFILEHEADER)lpBuf;
	lpInfo=(LPBITMAPINFOHEADER)(lpBuf+sizeof(BITMAPFILEHEADER));
	lpRGB= (RGBQUAD*)(lpBuf+sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER));
	lpPixel=(lpBuf+sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER)+(sizeof(RGBQUAD)*rgb_count));

	// BMP�t�@�C���̃w�b�_�쐬
	lpHead->bfType		= 'M'*256+'B';
	lpHead->bfSize		= dwFSize;
	lpHead->bfOffBits	= sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER)+(sizeof(RGBQUAD) * rgb_count);

	lpInfo->biSize		= sizeof(BITMAPINFOHEADER);
	lpInfo->biWidth		= dwWidth;
	lpInfo->biHeight	= dwHeight;
	lpInfo->biPlanes	= 1;
	lpInfo->biBitCount	= _biBitCount;

	// GetDIBits�ł͑I�����Ȃ����������炵���̂�
	memDC.SelectObject( pOldBitmap );
	// 
	GetDIBits(	memDC.GetSafeHdc(),
				(HBITMAP)bitmap,
				0,
				dwHeight,
				lpPixel,
				(LPBITMAPINFO)lpInfo,
				DIB_RGB_COLORS );

	// �o�b�t�@���t�@�C���ɏ����o��

	fh=CreateFile(lpszFileName,GENERIC_WRITE,0,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
	WriteFile(fh,lpBuf,dwFSize,&dwSize,NULL);
	CloseHandle(fh);

	GlobalFree(lpBuf);

	DeleteObject( bitmap );
	DeleteObject( font );


	return 0;
} 


/////////////////////////////////////////////////////////////////////////////
// main
/////////////////////////////////////////////////////////////////////////////

void usage()
{
	_tprintf( _T("Usage: fontdump {<fontface>|<bdf filename>} <from_code> [<to_code>] [-o=bmp][-e=<ebcode>] [-u=<unicode>] [-x=16] [-y=16] [-m=<gaijimap>][-h]\n") );
}

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;

	// MFC �̏���������я��������s���̃G���[�̏o��
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		// TODO: �K�v�ɉ����ăG���[ �R�[�h��ύX���Ă��������B
		cerr << _T("Fatal Error: MFC initialization failed") << endl;
		nRetCode = 1;
	}
	else
	{
		// TODO: ���̈ʒu�ɃA�v���P�[�V�����̓�����L�q���Ă��������B
		int _x	= 0;
		int _y	= 0;
		int _ebcode = 0xA121;
		int _unicode = 0xE000;
		TCHAR *_fontface = NULL;
		int _codeFrom = 0;
		int _codeTo = 0;
		int _ybase = 0;
		int _header	= 0;
		int _outtype	= 't';	// t:�e�L�X�g b:BMP
		CString s;
		TCHAR gaijiMapName[_MAX_FNAME+1] = _T("");


		///////////////////////////////////////////////////////////////
		// �I�v�V�����̉��
		///////////////////////////////////////////////////////////////
		int j=0;
		for ( int i=1; i<argc; ++i ) {
			if ( argv[i][0] == '-' || argv[i][0] == '/' ) {
				switch( argv[i][1] ) {
				case 'e':	// -e=ebcode
					_stscanf( argv[i]+3, _T("%X"), (char*)&_ebcode  );
					break;
				case 'u':	// -u=unicode
					_stscanf( argv[i]+3, _T("%X"), (char*)&_unicode  );
					break;
				case 'm':	// -m=gaijimap.xml
					_tcscpy( gaijiMapName, argv[i]+3 );
					break;
				case 'x':	// -x=16
					_x	= _ttoi( argv[i]+3 );
					break;
				case 'y':	// -y=16
					_y	= _ttoi( argv[i]+3 );
					if ( _y == 32 ) 
						_y	= 30;
					break;
				case 'b':
					_ybase	= _ttoi( argv[i]+3 );
					break;
				case 'o':
					_outtype	=  argv[i][3];
					break;
				case 'h':	// -h
					_header	= 1;
					break;
				case '0':	// -0=.
					blankDot	= argv[i][3];
					break;
				case '?':	// -?
					usage();
					return -1;
					break;
				}
			}
			else {
				switch ( j ) {
				case 0:	// fontface
					_fontface = argv[i];
					break;
				case 1:	// code_from
					_stscanf( argv[i], _T("%X"), (char*)&_codeFrom  );
					_codeTo	= _codeFrom;
					break;
				case 2:	// code_to
					_stscanf( argv[i], _T("%X"), (char*)&_codeTo );
					break;
				}
				++j;
			}
		}
		if ( j<1 ) {
			usage();
			return -1;
		}

		///////////////////////////////////////////////////////////////
		// �ϊ��̊J�n
		///////////////////////////////////////////////////////////////

		FILE *mapFp = NULL;
		if ( gaijiMapName[0] ) {
			mapFp = _tfopen( gaijiMapName, _T("w") );
		}

		CString sfont = CString(_fontface);
//		if ( strnicmp( _fontface+strlen(_fontface)-4, ".bdf",4 ) == 0 ) {
		if ( sfont.Right(4).CollateNoCase(_T(".bdf")) == 0 ) {
			// BDF����̕ϊ�
			ConvBDF2Txt( _fontface,		// BDF�t�@�C����
						_codeFrom,		// �J�n�R�[�h(�t�H���g�̃O���t�C���f�b�N�X)
						_codeTo,		// �I���R�[�h
						_ebcode,		// ���В�`�����̊J�n�R�[�h
						_unicode,		// ���蓖�Ă�Unicode
						_x,				// ���h�b�g�\��(0�̎��t�H���g�ɏ]��)
						_y,				// �c�h�b�g�\��(0�̎��t�H���g�ɏ]��)
						mapFp,			// GaijiMap�o�͗pFP
						_header );		// 1:XML�w�b�_�o��
		}
//		else if ( strnicmp( _fontface+strlen(_fontface)-4, ".hex",4 ) == 0 ) {
		else if ( sfont.Right(4).CollateNoCase(_T(".hex")) == 0 ) {
			// HEX����̕ϊ�
			ConvHEX2Txt( _fontface,		// HEX�t�@�C����
						_ebcode,		// ���В�`�����̊J�n�R�[�h
						_x,				// ���h�b�g�\��(0�̎��t�@�C���w�b�_�ɏ]��)
						_y,				// �c�h�b�g�\��(0�̎��t�@�C���w�b�_�ɏ]��)
						mapFp,			// GaijiMap�o�͗pFP
						_header );		// 1:XML�w�b�_�o��			
		}
		else {	// TTF����̕ϊ�
			if ( _x == 0 )	_x	= 16;
			if ( _y == 0 )	_y	= 16;

			if ( _header ) {	// XML�w�b�_�쐬
				printf( "<?xml version=\"1.0\" encoding=\"Shift_JIS\"?>\n");
				printf( "<gaijiData xml:space=\"preserve\">\n");
				printf( "<fontSet size=\"%dX%d\" start=\"%X\">\n",_x,_y,_ebcode);
				if ( mapFp ) {
					fprintf( mapFp, "<?xml version=\"1.0\" encoding=\"Shift_JIS\"?>\n");
					fprintf( mapFp, "<gaijiSet>\n");
				}
			}

			while ( _codeFrom <= _codeTo ) {			
				if ( _outtype == 'b' || _outtype == 'B' ) {	// bmp
					// BMP�t�@�C���ɏo��
					TCHAR _fname[_MAX_FNAME+1];
					_stprintf( _fname,_T("%04X.bmp"),_codeFrom);
					ConvTTF2BMP(
						_codeFrom,	// ���В�`�����̊J�n�R�[�h
						_x,			// ���h�b�g�\��(8,12,16,24,32,48)
						_y,			// �c�h�b�g�\��(16,24,30,48)
						_fontface,	// �t�H���g�t�F�[�X��
						_fname		// �o�̓t�@�C����
						);
				}
				else {
					// �e�L�X�g�`���ŕW���o�͂ɏo��
					ConvTTF2Txt( 
						_codeFrom,	// ���В�`�����̊J�n�R�[�h
						_x,			// ���h�b�g�\��(8,12,16,24,32,48)
						_y,			// �c�h�b�g�\��(16,24,30,48)
						_ebcode,	// ���В�`�����̊J�n�R�[�h
						_fontface,	// �t�H���g�t�F�[�X��
						_unicode,	// ���蓖�Ă�Unicode
						_ybase		// y�����̃x�[�X���C���I�t�Z�b�g
						 );
				}
				if ( mapFp ) {
					fprintf( mapFp, "<gaijiMap unicode=\"#x%04X\" ebcode=\"%04X\"/>\n", 
						_unicode, _ebcode );
				}

				++_codeFrom;
				++_unicode;
				++_ebcode;
				if ( ( _ebcode & 0xff ) > 0x7E ) {
					_ebcode = ((( _ebcode >> 8)+1)<<8) + 0x21;
				}
			}

			if ( _header ) {	// XML�w�b�_�쐬
				printf( "</fontSet>\n" );
				printf( "</gaijiData>\n" );
				if ( mapFp ) {
					fprintf( mapFp, "</gaijiSet>\n" );
				}
			}
		}
		
		if ( mapFp ) {
			fclose( mapFp );
		}

	}
	return nRetCode;
}


